package TP4.Temp.controller;

public interface EditTemp {
    double add(double temp);

    double less(double temp);
}
