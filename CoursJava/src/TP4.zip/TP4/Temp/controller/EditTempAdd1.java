package TP4.Temp.controller;

public class EditTempAdd1 implements EditTemp {
    public double add(double temp) {
        return temp + 1;
    }

    public double less(double temp) {
        return temp - 1;
    }
}
